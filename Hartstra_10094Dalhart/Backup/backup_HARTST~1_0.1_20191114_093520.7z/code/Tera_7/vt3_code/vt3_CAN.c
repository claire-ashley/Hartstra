/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#ifndef INCLUDE__VT3_CAN_C
#define INCLUDE__VT3_CAN_C

#include "vt3_CAN__CanInterface.c"
#include "vt3_CAN_common.c"
#endif /* INCLUDE__VT3_CAN_C */

/* end of file */
