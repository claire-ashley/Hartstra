/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#ifndef INCLUDE__VT3_POU__ST_TRANSLATE_H
#define INCLUDE__VT3_POU__ST_TRANSLATE_H

#include "vt3_base.h"
#include "vt3_POU_string_typedef.h"



/* FUNCTION declaration */
PSTRING ST_TRANSLATE(UINT ids, UINT language) ;




#endif /* INCLUDE__VT3_POU__ST_TRANSLATE_H */

/* end of file */
