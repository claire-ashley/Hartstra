/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#include "vt3_runtime.h"
#include "vt3_BMP__BluButtonStyle1_0_0.h"


/* file name:               blu_button_style_1.png */
/* format:                  disk file */
/* file size:               4934 bytes */
/* MD5 signature:           2d07b78f23125e5ad591987ac9db9488 */
const UINT8 FAR vt3_BMP__BluButtonStyle1_0_0[] = "blu_button_style_1.png";



/* end of file */
