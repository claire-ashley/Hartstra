/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#ifndef INCLUDE__VT3_BMP__YLWBUTTONSTYLE1_0_0_H
#define INCLUDE__VT3_BMP__YLWBUTTONSTYLE1_0_0_H

#include "vt3_base.h"


/* colour image:            ylw_button_style_1.png */
/* code generator format:   5 */
/* screen colour model is:  colour 16 bits (RGB565) */
/* file name:               ylw_button_style_1.png */
/* format:                  disk file */
/* file size:               4916 bytes */
/* MD5 signature:           38c00613228f5cf65f8a461df8d56dd6 */
extern const UINT8 FAR vt3_BMP__YlwButtonStyle1_0_0[];


#endif /* INCLUDE__VT3_BMP__YLWBUTTONSTYLE1_0_0_H */

/* end of file */
