/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#ifndef INCLUDE__VT3_BMP__GRYBUTTONSTYLE1_0_0_H
#define INCLUDE__VT3_BMP__GRYBUTTONSTYLE1_0_0_H

#include "vt3_base.h"


/* colour image:            gry_button_style_1.png */
/* code generator format:   5 */
/* screen colour model is:  colour 16 bits (RGB565) */
/* file name:               gry_button_style_1.png */
/* format:                  disk file */
/* file size:               5041 bytes */
/* MD5 signature:           0a9ec07ea28d77526275b4f0647a8603 */
extern const UINT8 FAR vt3_BMP__GryButtonStyle1_0_0[];


#endif /* INCLUDE__VT3_BMP__GRYBUTTONSTYLE1_0_0_H */

/* end of file */
