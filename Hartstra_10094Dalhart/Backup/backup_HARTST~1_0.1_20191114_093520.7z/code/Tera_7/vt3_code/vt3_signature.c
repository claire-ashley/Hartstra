/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* vt3 version:  8.9.2.0-STABLE */
/* this file has been generated automatically by vt3 - do not modify! */

#include "vt3_runtime.h"


/* the software signature */
const unsigned char FAR vt3_signature_software[16] = {
	0x9B, 0x6B, 0x1A, 0x32, 0xD7, 0x39, 0x8D, 0x09, 0xD2, 0xC9, 0xF9, 0xD2, 0x23, 0x36, 0x90, 0x82
};



/* end of file */
