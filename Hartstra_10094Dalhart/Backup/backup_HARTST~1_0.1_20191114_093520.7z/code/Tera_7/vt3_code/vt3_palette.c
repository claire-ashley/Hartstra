/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#ifndef INCLUDE__VT3_PALETTE_C
#define INCLUDE__VT3_PALETTE_C

#include "vt3_runtime.h"
#include "vt3_palette.h"


/* screen colour model is "colour 16 bits (RGB565)" so there is no palette */



#endif /* INCLUDE__VT3_PALETTE_C */

/* end of file */
