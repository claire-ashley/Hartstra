/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#include "vt3_runtime.h"
#include "vt3_BMP__YlwButtonStyle1_0_0.h"


/* file name:               ylw_button_style_1.png */
/* format:                  disk file */
/* file size:               4916 bytes */
/* MD5 signature:           38c00613228f5cf65f8a461df8d56dd6 */
const UINT8 FAR vt3_BMP__YlwButtonStyle1_0_0[] = "ylw_button_style_1.png";



/* end of file */
