/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#ifndef INCLUDE__VT3_VAR_VERSION_C
#define INCLUDE__VT3_VAR_VERSION_C

#include "vt3_runtime.h"
#include "vt3_POU_common.h"
#include "vt3_IO.h"



/** vt3 version */
const char FAR vt3_version[17] = "8.9.2.0-STABLE";


#endif /* INCLUDE__VT3_VAR_VERSION_C */

/* end of file */
