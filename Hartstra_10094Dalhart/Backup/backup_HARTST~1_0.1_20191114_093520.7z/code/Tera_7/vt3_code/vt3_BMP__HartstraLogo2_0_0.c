/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#include "vt3_runtime.h"
#include "vt3_BMP__HartstraLogo2_0_0.h"


/* file name:               hartstra logo 2.png */
/* format:                  disk file */
/* file size:               4578 bytes */
/* MD5 signature:           a98fa7ab95f36059d2b3db8dbe0024e1 */
const UINT8 FAR vt3_BMP__HartstraLogo2_0_0[] = "hartstra logo 2.png";



/* end of file */
