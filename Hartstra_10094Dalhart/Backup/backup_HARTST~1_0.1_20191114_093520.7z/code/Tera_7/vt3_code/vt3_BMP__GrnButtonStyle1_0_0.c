/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#include "vt3_runtime.h"
#include "vt3_BMP__GrnButtonStyle1_0_0.h"


/* file name:               grn_button_style_1.png */
/* format:                  disk file */
/* file size:               4217 bytes */
/* MD5 signature:           d7c1a0cb1e9602dc0e305176518579aa */
const UINT8 FAR vt3_BMP__GrnButtonStyle1_0_0[] = "grn_button_style_1.png";



/* end of file */
