/* device:       /project/Tera_7 */
/* device model: TERA7 */
/* this file has been generated automatically by vt3 - do not modify! */


#ifndef INCLUDE__VT3_ALARMS_H
#define INCLUDE__VT3_ALARMS_H

#include "vt3_base.h"
#include "vt3_elog.h"



/* priority levels */
#define VT3_COUNTOF_ALARM_PRIORITY (0)

/* spn numbers */
#define VT3_COUNTOF_ALARM_SPN (0)

/* fmi numbers */
#define VT3_COUNTOF_ALARM_FMI (0)

/* group numbers */
#define VT3_COUNTOF_ALARM_GROUP (0)

/* local alarms numbers */
#define VT3_COUNTOF_LOCAL_ALARMS (0)

/* global alarms numbers */
#define VT3_COUNTOF_GLOBAL_ALARMS (0)


#endif /* INCLUDE__VT3_ALARMS_H */

/* end of file */
