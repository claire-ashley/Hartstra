// file: vt3_extra.c
// this file belongs to the initial project configuration and is intially empty

#include "vt3_extra.h"

