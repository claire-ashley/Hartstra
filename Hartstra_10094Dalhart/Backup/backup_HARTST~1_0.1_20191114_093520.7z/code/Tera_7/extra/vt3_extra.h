// file: vt3_extra.h
// this file belongs to the initial project configuration and is intially empty



#ifndef VT3_EXTRA_H
#define VT3_EXTRA_H

#endif