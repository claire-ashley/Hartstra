Date and time:     Thu Nov 14 09:35:14 2019
Computer name:     5ZPNTN2
User name:         ashlc00
Windows version:   6.2.9200.2 
Version of vt3:    8.9.2.0-STABLE

Project:           C:\Users\ashlc00\DOCUME~1\Hartstra\DALHAR~1\HARTST~2\HARTST~1.VT3
Project version:   0.1
Device:            Tera_7
Source address:    18

File name        Size (bytes)
.\arialbd.ttf        750596
.\blu_button_style_1.png       4361
.\can_daemon          28273
.\extra_files_readme.txt        135
.\grn_button_style_1.png       3777
.\gry_button_style_1.png       4466
.\hartstra logo 1.png      75858
.\hartstra logo 2.png       4718
.\red_button_style_1.png       4377
.\vt3_app            643644
.\ylw_button_style_1.png       4365

End of manifest
