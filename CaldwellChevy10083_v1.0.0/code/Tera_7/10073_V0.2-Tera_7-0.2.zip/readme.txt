Date and time:     Tue Oct 08 09:55:18 2019
Computer name:     912QNF2
User name:         scogs00
Windows version:   6.2.9200.2 
Version of vt3:    8.9.1.1-STABLE

Project:           C:\Users\scogs00\Documents\Customers\Harstra\10073_V0.2\Hartstra_10073GrandeFord\10073_V0.2.vt3
Project version:   0.2
Device:            Tera_7
Source address:    18

File name        Size (bytes)
.\arialbd.ttf        750596
.\blu_button_style_1.png       4361
.\can_daemon          28273
.\extra_files_readme.txt        135
.\grn_button_style_1.png       3777
.\gry_button_style_1.png       4466
.\hartstra logo 1.png      75858
.\hartstra logo 2.png       4718
.\red_button_style_1.png       4377
.\vt3_app            625099
.\ylw_button_style_1.png       4365

End of manifest
