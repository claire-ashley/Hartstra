Date and time:     Thu Jun 21 08:31:09 2018
Computer name:     1F292G2
User name:         Hurdj00
Windows version:   6.2.9200.2 
Version of vt3:    8.9.0.3-PATCH

Project:           C:\Users\hurdj00\Desktop\Hartstra_10041_V0.1\Hartstra_10041_V0.1.vt3
Project version:   0.1
Device:            Tera_7
Source address:    18

File name        Size (bytes)
.\arialbd.ttf        750596
.\blu_button_style_1.png       4361
.\can_daemon          27898
.\extra_files_readme.txt        135
.\grn_button_style_1.png       3777
.\gry_button_style_1.png       4466
.\hartstra logo 1.png      75858
.\hartstra logo 2.png       4718
.\red_button_style_1.png       4377
.\vt3_app            512662
.\ylw_button_style_1.png       4365

End of manifest
